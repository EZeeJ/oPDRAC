<?php
 
include 'producten.php';
 
$dbproduct = new product ($myDb);
 
try {
    $dbproduct->deleteproduct($_GET['product_id']);
    header("Location:select.php");
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
  }
 
?>